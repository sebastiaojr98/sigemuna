# SMSGateway Change Log

## Version 1.0.9 (2023-09-20)

### Fixed bugs
* PHP 8.1 fix (thanks to ratmole)

## Version 1.0.8 (2023-03-30)

### Fixed bugs
* Better json decoding, ignoring chr(13)

## Version 1.0.6 (2023-03-21)

### Enhancements
* Enhanced gateway example

## Version 1.0.5 (2022-10-17)

### Enhancements
* Enhanced gateway example

## Version 1.0.4 (2022-10-13)

### Enhancements
* More sent messages attributes
* Full gateway example

### Fixed bugs
* Descending sorted messages

## Version 1.0.3 (2022-10-11)
* First public version

## Version 0.0.1 (2022-09-10) (unreleased)
* Initial implementation
